dec=123

print(bin(dec))

print(oct(dec))

print(hex(dec))